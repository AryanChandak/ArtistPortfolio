"use client"

import { useState, useRef, useEffect } from "react"
import { motion, useInView } from "framer-motion"
import { ExternalLink, ShoppingCart, ShoppingBag, Star, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/utils/supabase/client"
import { useCart } from "./cart-context"

interface Product {
  id: string
  title: string
  description: string
  price: string
  originalPrice?: string
  image: string
  category: string
  rating: number
  reviews: number
  featured: boolean
  externalLink: string
}

const ShopSection = () => {
  const [products, setProducts] = useState<Product[]>([])
  const { addToCart } = useCart()
  
  useEffect(() => {
    const fetchShopItems = async () => {
      const supabase = createClient()
      const { data } = await supabase.from('shop_items').select('*').order('created_at', { ascending: false })
      if (data) {
        // Map DB keys to React interface
        const formatted = data.map(item => ({
          ...item,
          originalPrice: item.original_price,
          externalLink: item.external_link
        }))
        setProducts(formatted)
      }
    }
    fetchShopItems()
  }, [])
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const featuredProducts = products.filter((product) => product.featured)
  const regularProducts = products.filter((product) => !product.featured)

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-3 h-3 sm:w-4 sm:h-4 ${
          i < Math.floor(rating)
            ? "text-primary fill-current"
            : i < rating
              ? "text-primary fill-current opacity-50"
              : "text-foreground/20"
        }`}
      />
    ))
  }

  return (
    <section id="shop" ref={ref} className="py-20 sm:py-28 lg:py-32 bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_30%,rgba(200,160,74,0.05),transparent_60%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-6">
            <span className="inline-flex items-center space-x-2 border border-primary/30 rounded-full px-5 py-2 glow-gold">
              <Package className="w-4 h-4 text-primary" />
              <span className="text-xs tracking-[0.2em] font-medium uppercase text-primary">Art & Merchandise</span>
            </span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-[var(--font-playfair)] font-light mb-6 text-foreground">
            The <span className="text-gradient-gold">Shop</span>
          </h2>
          <div className="w-12 h-[1px] bg-primary/50 mx-auto mb-6" />
          <p className="text-lg sm:text-xl text-foreground/60 max-w-2xl mx-auto font-light">
            Take home a piece of my artistic journey with prints, books, and exclusive collections
          </p>
        </motion.div>

        {/* Featured Products */}
        {featuredProducts.length > 0 && (
            <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-20"
            >
            <h3 className="text-xl sm:text-2xl font-[var(--font-playfair)] mb-8 text-center uppercase tracking-widest text-foreground/80">Featured Editions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
                {featuredProducts.map((product, index) => (
                <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="group relative bg-card rounded-xl overflow-hidden hover:shadow-[0_20px_40px_rgba(200,160,74,0.1)] transition-all duration-500 transform hover:-translate-y-2 border border-border"
                >
                    <div className="absolute top-4 left-4 z-10 px-3 py-1 bg-background/80 backdrop-blur-md border border-primary/30 text-primary text-[10px] tracking-widest uppercase shadow-md">
                        Featured
                    </div>

                    <div className="relative overflow-hidden aspect-[4/3] bg-foreground/5">
                        <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.title}
                            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-background via-black/10 to-transparent opacity-80" />
                    </div>

                    <div className="p-6 sm:p-8 relative bg-card -mt-10 rounded-t-2xl border-t border-border/50 mx-2 glow-gold z-20 shadow-lg">
                        <div className="flex items-center justify-between mb-4">
                            <span className="text-[10px] tracking-[0.2em] uppercase text-foreground/50 border border-border px-2 py-1">
                            {product.category}
                            </span>
                            <div className="flex items-center space-x-1">
                                {renderStars(product.rating)}
                                <span className="text-xs text-foreground/40 ml-2">({product.reviews})</span>
                            </div>
                        </div>

                        <h3 className="text-xl sm:text-2xl font-[var(--font-playfair)] mb-3 group-hover:text-primary transition-colors text-foreground line-clamp-1">
                            {product.title}
                        </h3>

                        <p className="text-foreground/60 mb-6 text-sm font-light line-clamp-2">
                            {product.description}
                        </p>

                        <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
                            <div className="flex flex-col">
                                <span className="text-lg sm:text-xl font-medium text-foreground">{product.price}</span>
                                {product.originalPrice && (
                                <span className="text-xs text-foreground/40 line-through">{product.originalPrice}</span>
                                )}
                            </div>
                            <Button
                                onClick={() => addToCart({
                                    id: product.id,
                                    title: product.title,
                                    price: product.price,
                                    image: product.image,
                                    category: product.category,
                                    quantity: 1
                                })}
                                size="sm"
                                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-widest uppercase glow-gold rounded-none"
                            >
                                <ShoppingCart className="w-4 h-4 mr-2" />
                                Add to Cart
                            </Button>
                        </div>
                    </div>
                </motion.div>
                ))}
            </div>
            </motion.div>
        )}

        {/* Regular Products */}
        {regularProducts.length > 0 && (
            <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            >
            <h3 className="text-lg sm:text-xl font-[var(--font-playfair)] mb-8 text-center uppercase tracking-widest text-foreground/70">Gallery Collection</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {regularProducts.map((product, index) => (
                <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                    className="group flex flex-col bg-card rounded-md overflow-hidden hover:shadow-[0_10px_30px_rgba(200,160,74,0.08)] transition-all duration-500 border border-border"
                >
                    <div className="relative overflow-hidden aspect-square border-b border-border">
                        <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.title}
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter grayscale-[20%] group-hover:grayscale-0"
                        />
                    </div>

                    <div className="p-5 flex flex-col flex-grow">
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-[9px] tracking-[0.2em] uppercase text-primary/70">
                            {product.category}
                            </span>
                            <div className="flex items-center space-x-1">
                                {renderStars(product.rating)}
                            </div>
                        </div>

                        <h3 className="text-base font-[var(--font-playfair)] mb-2 group-hover:text-primary transition-colors text-foreground line-clamp-1">
                            {product.title}
                        </h3>

                        <p className="text-foreground/50 mb-4 text-xs font-light line-clamp-2">
                            {product.description}
                        </p>

                        <div className="flex items-center justify-between mt-auto pt-3 border-t border-border/30">
                            <span className="text-base font-medium text-foreground/90">{product.price}</span>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => addToCart({
                                    id: product.id,
                                    title: product.title,
                                    price: product.price,
                                    image: product.image,
                                    category: product.category,
                                    quantity: 1
                                })}
                                className="border-border text-foreground hover:bg-primary/5 hover:text-primary hover:border-primary/50 text-[10px] tracking-widest uppercase transition-all duration-300 rounded-none h-8 px-3"
                            >
                                <ShoppingBag className="w-3 h-3 mr-1.5" />
                                Cart
                            </Button>
                        </div>
                    </div>
                </motion.div>
                ))}
            </div>
            </motion.div>
        )}

        {/* Empty state */}
        {products.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <p className="text-lg text-foreground/50 font-light italic">Store items empty. Add products from the dashboard.</p>
          </motion.div>
        )}

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-20 sm:mt-24 p-8 sm:p-12 relative overflow-hidden border border-primary/20 bg-background"
        >
          {/* Subtle glow / grid behind the CTA */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(200,160,74,0.08),transparent_70%)]" />
          
          <div className="relative z-10">
            <h3 className="text-2xl sm:text-3xl font-[var(--font-playfair)] mb-4 text-foreground">Commission a Masterpiece</h3>
            <div className="w-16 h-[1px] bg-primary/40 mx-auto mb-6" />
            <p className="text-foreground/60 mb-8 max-w-2xl mx-auto font-light">
                I offer personalized commissions and custom artwork tailored to your specific spatial and emotional requirements. Let's collaborate.
            </p>
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-6 text-xs font-semibold tracking-[0.2em] uppercase glow-gold transition-all duration-500 rounded-none">
                Start a Conversation
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default ShopSection

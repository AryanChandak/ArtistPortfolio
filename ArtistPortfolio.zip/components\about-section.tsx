"use client"

import { useRef } from "react"
import { motion, useInView, useScroll, useTransform } from "framer-motion"

const AboutSection = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })

  const bgY = useTransform(scrollYProgress, [0, 1], [60, -60])

  return (
    <section id="about" ref={ref} className="py-20 sm:py-28 lg:py-32 relative overflow-hidden bg-background">
      {/* Animated background gradient */}
      <motion.div
        style={{ y: bgY }}
        className="absolute inset-0 bg-background -z-10"
      />

      {/* Floating particles background */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[100px] mix-blend-screen" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-warm/10 rounded-full blur-[100px] mix-blend-screen" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div className="order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="inline-block mb-4"
            >
              <span className="px-4 py-1.5 border border-primary/30 rounded-full text-xs tracking-[0.2em] uppercase text-primary font-medium">
                About Me
              </span>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, x: -40 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="text-4xl sm:text-5xl md:text-6xl font-[var(--font-playfair)] font-light mb-8 text-foreground"
            >
              About The <span className="text-gradient-gold">Vision</span>
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-6 text-base sm:text-lg text-foreground/70 leading-relaxed font-light"
            >
                My name is **Puja Dhanuka**, and I am a visual storyteller who believes that every image holds the power to transcend language, culture,
                and time. My journey began with a simple camera and an insatiable curiosity about the world around me.
              <p>
                Over the years, I've evolved from capturing moments to crafting entire visual narratives that speak to
                the soul. My work spans across digital art, photography, and immersive experiences that challenge
                conventional boundaries.
              </p>
              <p>
                Each piece in my portfolio represents a chapter in my ongoing exploration of human emotion, natural
                beauty, and the intersection of technology with art.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="mt-12 grid grid-cols-3 gap-4 sm:gap-6"
            >
              {[
                { number: "500+", label: "Projects" },
                { number: "100+", label: "Connections" },
                { number: "20+", label: "Years" },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05, y: -4 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                  className="text-center p-6 bg-card border border-border/50 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 glow-gold cursor-default group"
                >
                  <div className="text-2xl sm:text-4xl font-[var(--font-playfair)] text-foreground group-hover:text-primary transition-colors duration-300 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-xs sm:text-sm text-foreground/50 uppercase tracking-widest">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 40 }}
            animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
            transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative order-1 lg:order-2 flex justify-center"
          >
            <div className="relative w-full max-w-sm sm:max-w-md">
              {/* Elegant floating frame effect */}
              <div className="absolute inset-0 bg-primary/20 transform translate-x-4 translate-y-4 rounded-xl -z-10" />
              
              <div className="relative overflow-hidden rounded-xl bg-card border border-border p-2 shadow-2xl">
                <img
                  src="/placeholder.svg?height=700&width=550"
                  alt="Artist Puja Dhanuka"
                  className="w-full h-80 sm:h-96 lg:h-[32rem] object-cover rounded-lg filter grayscale hover:grayscale-0 transition-all duration-700"
                />
              </div>

              {/* Decorative minimalist elements */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="absolute -top-12 -right-12 w-24 h-24 border border-primary/20 rounded-full opacity-50"
              />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                className="absolute -bottom-8 -left-8 w-32 h-32 border border-accent-warm/20 rounded-full opacity-50"
              />
            </div>
          </motion.div>
        </div>

        {/* Creative Process */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mt-24 sm:mt-32 text-center"
        >
          <div className="mb-16">
            <h3 className="text-3xl sm:text-4xl font-[var(--font-playfair)] font-light mb-4 text-foreground">My Creative Process</h3>
            <div className="w-16 h-[1px] bg-primary/50 mx-auto" />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {[
              { step: "01", title: "Inspiration", desc: "Finding the spark in everyday moments" },
              { step: "02", title: "Concept", desc: "Developing the visual narrative" },
              { step: "03", title: "Creation", desc: "Bringing ideas to life through art" },
              { step: "04", title: "Refinement", desc: "Perfecting every detail" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -8 }}
                className="group p-8 bg-card border border-border/50 rounded-xl hover:border-primary/50 transition-all duration-500 hover:shadow-[0_10px_30px_rgba(200,160,74,0.1)] relative overflow-hidden"
              >
                {/* Number watermark */}
                <div className="absolute -top-4 -right-4 text-8xl font-[var(--font-playfair)] font-bold text-foreground/[0.03] group-hover:text-primary/[0.05] transition-colors duration-500 z-0 select-none">
                  {item.step}
                </div>
                
                <div className="relative z-10 flex flex-col items-center">
                  <div className="text-xl font-[var(--font-playfair)] text-primary mb-6 transition-transform duration-300">
                    {item.step}.
                  </div>
                  <h4 className="text-lg font-medium tracking-wide uppercase mb-3 text-foreground">{item.title}</h4>
                  <p className="text-sm text-foreground/60 font-light">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default AboutSection

"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence, useInView } from "framer-motion"
import { X, ExternalLink, Maximize2, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/utils/supabase/client"

interface PortfolioItem {
  id: string
  title: string
  category: string
  image: string
  description: string
  tags: string[]
  year: string
  client?: string
}

const categories = ["All", "Digital Art", "Photography", "Portrait", "Prints", "Commission"]

const PortfolioSection = () => {
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null)
  
  useEffect(() => {
    const fetchPortfolio = async () => {
      const supabase = createClient()
      const { data } = await supabase.from('portfolio_items').select('*').order('created_at', { ascending: false })
      if (data) setPortfolioItems(data)
    }
    fetchPortfolio()
  }, [])

  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  const filteredItems =
    selectedCategory === "All" ? portfolioItems : portfolioItems.filter((item) => item.category === selectedCategory)

  // Infinite image carousel logic just needs duplicated items to scroll seamlessly
  const infiniteItems = portfolioItems.length > 0 
    ? [...portfolioItems, ...portfolioItems, ...portfolioItems].slice(0, 10) 
    : [];

  return (
    <section id="portfolio" ref={ref} className="py-20 sm:py-28 lg:py-32 bg-background relative overflow-hidden">
      {/* Subtle background texture */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(200,160,74,0.03),transparent_70%)]" />

      {/* INFINITE IMAGE CAROUSEL BACKGROUND EFFECT */}
      {infiniteItems.length > 0 && (
        <div className="absolute top-0 left-0 right-0 h-64 overflow-hidden opacity-[0.03] dark:opacity-[0.05] pointer-events-none z-0">
          <div className="flex animate-[marquee_60s_linear_infinite] w-max gap-4 p-4">
            {infiniteItems.map((item, i) => (
              <div key={i} className="w-64 h-48 bg-card rounded-lg overflow-hidden shrink-0">
                 <img src={item.image} alt="" className="w-full h-full object-cover grayscale" />
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 border border-primary/30 rounded-full text-xs tracking-[0.2em] uppercase text-primary font-medium mb-6">
            My Work
          </span>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-[var(--font-playfair)] font-light mb-6 text-foreground">
            Curated <span className="text-gradient-gold">Portfolio</span>
          </h2>
          <div className="w-12 h-[1px] bg-primary/50 mx-auto mb-6" />
          <p className="text-lg sm:text-xl text-foreground/60 max-w-2xl mx-auto font-light">
            A visual anthology exploring the intersection of light, emotion, and perception
          </p>
        </motion.div>

        {/* Category Filter — Elegant unboxed text links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-wrap justify-center gap-6 sm:gap-10 mb-16 border-y border-border/50 py-4"
        >
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ y: -2 }}
              onClick={() => setSelectedCategory(category)}
              className={`text-xs sm:text-sm tracking-[0.15em] uppercase font-medium transition-all duration-300 relative py-1 ${
                selectedCategory === category
                  ? "text-primary"
                  : "text-foreground/50 hover:text-foreground"
              }`}
            >
              {category}
              {selectedCategory === category && (
                <motion.div
                  layoutId="activeCategory"
                  className="absolute -bottom-1 left-0 right-0 h-[1px] bg-primary"
                />
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Dynamic Infinite Scroll Carousel when "All" is selected, otherwise Grid */}
        {selectedCategory === "All" && filteredItems.length > 3 ? (
             <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }} 
               className="relative w-screen -mx-4 sm:-mx-6 lg:-mx-8 lg:w-[calc(100vw-scrollbar)] left-1/2 right-1/2 -ml-[50vw] -mr-[50vw] overflow-hidden py-10"
             >
                <div className="marquee-track flex gap-8 px-4 hover:[animation-play-state:paused]">
                    {[...filteredItems, ...filteredItems].map((item, index) => (
                        <div
                            key={`${item.id}-${index}`}
                            className="group cursor-pointer shrink-0 w-[80vw] sm:w-[500px] md:w-[600px] lg:w-[700px] relative transition-transform duration-700 ease-out hover:scale-[1.02]"
                            onClick={() => setSelectedItem(item)}
                        >
                            <div className="relative overflow-hidden rounded-sm aspect-[16/9] shadow-xl glow-gold">
                                <img
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.title}
                                    className="w-full h-full object-cover filter contrast-125 saturate-50 group-hover:saturate-100 transition-all duration-700 ease-out group-hover:scale-105"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-60 group-hover:opacity-80 transition-all duration-500" />
                                
                                <div className="absolute bottom-0 left-0 right-0 p-8 transform translate-y-4 group-hover:translate-y-0 transition-all duration-700 ease-out">
                                    <p className="text-primary tracking-[0.2em] text-xs uppercase mb-2 drop-shadow-md font-medium">{item.category}</p>
                                    <h3 className="text-white font-[var(--font-playfair)] text-3xl sm:text-4xl mb-4 font-light leading-snug drop-shadow-lg">{item.title}</h3>
                                    
                                    <div className="inline-flex items-center text-white/80 hover:text-white text-sm tracking-widest uppercase transition-colors overflow-hidden group/btn">
                                       <span className="transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 mr-2">View</span>
                                       <ArrowRight className="w-4 h-4 transform -translate-x-12 group-hover:translate-x-0 transition-transform duration-500 delay-75" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
             </motion.div>
        ) : (
            <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
            <AnimatePresence mode="popLayout">
                {filteredItems.map((item, index) => (
                <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 40, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{
                    duration: 0.6,
                    delay: index * 0.1,
                    ease: [0.22, 1, 0.36, 1],
                    }}
                    className="group cursor-pointer"
                    onClick={() => setSelectedItem(item)}
                >
                    <div className="relative overflow-hidden bg-card aspect-[4/5] shadow-lg glow-gold">
                    <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105 filter saturate-50 group-hover:saturate-100"
                    />
                    <div className="absolute inset-0 bg-background/0 group-hover:bg-background/10 transition-colors duration-500" />
                    
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-500 transform -translate-y-2 group-hover:translate-y-0">
                        <div className="bg-background/80 backdrop-blur-md rounded-full p-3 border border-border">
                        <Maximize2 className="w-4 h-4 text-primary" />
                        </div>
                    </div>
                    </div>
                    <div className="mt-6 text-center">
                       <p className="text-primary/80 tracking-[0.2em] text-[10px] uppercase mb-2">{item.category}</p>
                       <h3 className="text-foreground font-[var(--font-playfair)] text-xl mb-1">{item.title}</h3>
                    </div>
                </motion.div>
                ))}
            </AnimatePresence>
            </motion.div>
        )}

        {/* Empty state */}
        {filteredItems.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <p className="text-lg text-foreground/50 font-light italic">No pieces curated in this collection yet.</p>
          </motion.div>
        )}

        {/* Elegant Modal */}
        <AnimatePresence>
          {selectedItem && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-8"
              onClick={() => setSelectedItem(null)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.98, opacity: 0, y: 10 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="bg-card w-full max-w-6xl max-h-[95vh] overflow-y-auto shadow-2xl flex flex-col lg:flex-row border border-border"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Image side */}
                <div className="w-full lg:w-2/3 relative bg-black/5 dark:bg-black/40 flex items-center justify-center p-8">
                  <img
                    src={selectedItem.image || "/placeholder.svg"}
                    alt={selectedItem.title}
                    className="max-w-full max-h-[70vh] object-contain shadow-2xl"
                  />
                  <button
                    className="absolute top-4 right-4 sm:hidden bg-background/50 backdrop-blur-md text-foreground p-2 rounded-full"
                    onClick={() => setSelectedItem(null)}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Details side */}
                <div className="w-full lg:w-1/3 p-8 sm:p-12 flex flex-col justify-center relative">
                   <button
                    className="hidden sm:block absolute top-6 right-6 text-foreground/50 hover:text-foreground transition-colors"
                    onClick={() => setSelectedItem(null)}
                  >
                    <X className="w-6 h-6" />
                  </button>

                  {selectedItem.tags && selectedItem.tags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 mb-6">
                      {selectedItem.tags.map((tag) => (
                        <span key={tag} className="text-[10px] uppercase tracking-[0.2em] text-primary/80 border border-border px-2 py-1">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <h3 className="text-3xl sm:text-4xl font-[var(--font-playfair)] mb-4 text-foreground leading-tight">{selectedItem.title}</h3>
                  <div className="w-8 h-[1px] bg-primary flex-shrink-0 mb-6" />
                  
                  <p className="text-foreground/70 mb-10 text-sm leading-relaxed font-light">
                    {selectedItem.description}
                  </p>

                  <div className="flex flex-col gap-4 text-xs tracking-widest text-foreground/50 mb-12 uppercase border-t border-border pt-8">
                    {selectedItem.year && (
                        <div className="flex justify-between">
                            <span>Year</span>
                            <span className="text-foreground">{selectedItem.year}</span>
                        </div>
                    )}
                    {selectedItem.client && (
                        <div className="flex justify-between">
                            <span>Client</span>
                            <span className="text-foreground">{selectedItem.client}</span>
                        </div>
                    )}
                  </div>

                  <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 text-xs tracking-[0.2em] uppercase py-6 rounded-none glow-gold transition-all duration-300">
                    <ExternalLink className="w-4 h-4 mr-3" />
                    View Exhibition
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

export default PortfolioSection

"use client"

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import { Mail, Instagram, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const HeroSection = () => {
  const containerRef = useRef(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  })

  // Subtle parallax for the main image
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"])
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "40%"])

  const handleContactClick = () => {
    window.location.href = "mailto:thevisual.art1@gmail.com"
  }

  const scrollToPortfolio = () => {
    const element = document.querySelector("#portfolio")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section
      id="hero"
      ref={containerRef}
      className="relative min-h-screen pt-24 pb-12 flex flex-col justify-center overflow-hidden bg-background"
    >
      {/* Background ambient light */}
      <div className="absolute -top-[20%] -right-[10%] w-[70%] h-[70%] bg-[radial-gradient(ellipse_at_center,rgba(200,160,74,0.08),transparent_70%)] pointer-events-none rounded-full blur-[100px]" />
      
      <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-12 w-full flex-grow flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-24 relative z-10">
        
        {/* Left Side: Typography & CTA */}
        <motion.div 
          style={{ y: textY }}
          className="w-full lg:w-5/12 flex flex-col justify-center pt-10 lg:pt-0"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="mb-6 flex items-center space-x-4"
          >
            <span className="w-12 h-px bg-primary/60" />
            <span className="text-xs tracking-[0.3em] uppercase text-primary font-medium">
              Contemporary Artist
            </span>
          </motion.div>

          <div className="overflow-hidden mb-6">
            <motion.h1
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="text-7xl sm:text-8xl md:text-9xl lg:text-[10rem] font-[var(--font-playfair)] leading-[0.85] tracking-tighter text-foreground drop-shadow-sm"
            >
              The <br className="hidden lg:block" />
              <span className="bg-gradient-to-br from-[#C8A04A] via-[#E8C86A] to-[#B8903A] bg-clip-text text-transparent italic pr-4">Visual</span>
            </motion.h1>
          </div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="text-lg sm:text-xl text-foreground/60 max-w-md mb-10 font-light leading-relaxed"
          >
            A curated anthology of light, emotion, and perception. Transcending the ordinary through visual storytelling.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col sm:flex-row gap-5 items-start sm:items-center"
          >
            <Button
              size="lg"
              onClick={scrollToPortfolio}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-7 text-xs tracking-[0.2em] font-medium uppercase transition-all duration-500 glow-gold rounded-none"
            >
              Enter Gallery
              <ArrowRight className="w-4 h-4 ml-3" />
            </Button>
            <button
              onClick={handleContactClick}
              className="flex items-center text-xs tracking-[0.2em] uppercase font-medium text-foreground/70 hover:text-primary transition-colors group px-4 py-4"
            >
              <Mail className="w-4 h-4 mr-3 group-hover:scale-110 transition-transform" />
              Inquiries
            </button>
          </motion.div>
        </motion.div>

        {/* Right Side: Prominent Hero Image */}
        <motion.div 
          className="w-full lg:w-7/12 relative aspect-[4/5] lg:aspect-[3/4] max-h-[85vh]"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* Decorative frame elements */}
          <div className="absolute -inset-4 border border-border/40 z-0 hidden md:block" />
          <div className="absolute -inset-8 border border-border/20 z-0 hidden lg:block" />
          
          <div className="relative w-full h-full overflow-hidden bg-card z-10 shadow-2xl group">
            <motion.img
              style={{ y: imgY, scale: 1.15 }}
              src="/placeholder.svg?height=1200&width=900"
              alt="Featured Artwork"
              className="w-full h-full object-cover filter saturate-50 contrast-125 transition-all duration-1000 group-hover:saturate-100 group-hover:scale-[1.20] origin-center"
            />
            {/* Elegant gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-80" />
            
            {/* Image caption */}
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end border-t border-white/20 pt-4">
               <div>
                  <p className="text-white/80 font-[var(--font-playfair)] text-xl">Featured Exhibition</p>
                  <p className="text-white/50 text-xs tracking-[0.2em] uppercase mt-1">2026 Collection</p>
               </div>
               <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center backdrop-blur-md">
                   <ArrowRight className="w-4 h-4 text-white -rotate-45" />
               </div>
            </div>
          </div>
        </motion.div>

      </div>

      {/* Infinite Scrolling Marquee Banner (Bottom Edge) */}
      <div className="absolute bottom-0 left-0 right-0 overflow-hidden py-3 bg-card border-y border-border/50 z-20">
        <div className="marquee-track flex items-center space-x-12 text-xs font-semibold tracking-[0.3em] uppercase text-foreground/50">
          {["Editorial", "•", "Fine Art", "•", "Visual Media", "•", "Creative Direction", "•", "Immersive Experiences", "•", "Photography", "•"].flatMap(a => [a, a, a]).map((item, i) => (
             <span key={i} className={item === "•" ? "text-primary/40" : ""}>{item}</span>
          ))}
        </div>
      </div>
    </section>
  )
}

export default HeroSection
